TODO
- create measure for OpenStudio (fetch OSM elements like the opyplus helper does for IDF)

- create helper classes for cleaning models up (remove duplicates, etc.)
