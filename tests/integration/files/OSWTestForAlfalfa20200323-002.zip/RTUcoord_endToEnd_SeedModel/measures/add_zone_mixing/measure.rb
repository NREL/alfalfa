# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class AddZoneMixing < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    # Measure name should be the title case of the class name.
    return 'Add Zone Mixing '
  end

  # human readable description
  def description
    return 'Add Zone Mixing between two zones'
  end

  # human readable description of modeling approach
  def modeler_description
    return 'Adds two zone mixing objects - one for each specified zone with same schedule and flow'
  end

  # define the arguments that the user will input
  def arguments(model)
      args = OpenStudio::Measure::OSArgumentVector.new

      # the name of the zone 1
      zone1_name = OpenStudio::Measure::OSArgument.makeStringArgument('zone1_name', true)
      zone1_name.setDisplayName('Zone 1')
      args << zone1_name

      # the name of the zone 2
      zone2_name = OpenStudio::Measure::OSArgument.makeStringArgument('zone2_name', true)
      zone2_name.setDisplayName('Zone 2')
      args << zone2_name

      # the name of the schedule
      schedule_name = OpenStudio::Measure::OSArgument.makeStringArgument('schedule_name', true)
      schedule_name.setDisplayName('Schedule Name for Zone Mixing')
      args << schedule_name

      # design level for zone mixing
      design_level = OpenStudio::Measure::OSArgument.makeDoubleArgument('design_level', true)
      design_level.setDisplayName('Design Level for Zone Mixing')
      design_level.setUnits('cfm')
      args << design_level

      return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables
    zone1_name = runner.getStringArgumentValue('zone1_name', user_arguments)
    zone2_name = runner.getStringArgumentValue('zone2_name', user_arguments)
    schedule_name = runner.getStringArgumentValue('schedule_name', user_arguments)
    design_level = runner.getDoubleArgumentValue('design_level', user_arguments)

    # validate input names and get zones
    zone1_name_valid = false
    zone2_name_valid = false
    zone1 = nil
    zone2 = nil
    model.getThermalZones.each do |zone|
      if zone.name.to_s == zone1_name
        zone1_name_valid = true
        zone1 = zone
      elsif zone.name.to_s == zone2_name
        zone2_name_valid = true
        zone2 = zone
      end
    end

    # error if didn't find zones
    if (zone1_name_valid == false) || (zone2_name_valid == false)
      runner.registerError('One or more of the expected zones could not be found.')
      return false
    end

    # validate design level input
    if design_level < 0.0
      runner.registerError('Choose a non negative number for design level.')
      return false
    end

    schedule = nil
    if not model.getScheduleConstantByName(schedule_name).empty?
      schedule = model.getScheduleConstantByName(schedule_name).get.to_Schedule.get
    end

    zone1Mixing = OpenStudio::Model::ZoneMixing.new(zone1)
    zone1Mixing.setName("#{zone1_name}_Mixing_with_#{zone2_name}")
    zone1Mixing.setSchedule(schedule)
    zone1Mixing.setDesignFlowRate(design_level)
    zone1Mixing.setSourceZone(zone2)

    zone2Mixing = OpenStudio::Model::ZoneMixing.new(zone2)
    zone2Mixing.setName("#{zone2_name}_Mixing_with_#{zone1_name}")
    zone2Mixing.setSchedule(schedule)
    zone2Mixing.setDesignFlowRate(design_level)
    zone2Mixing.setSourceZone(zone1)

    # report initial condition of model
    runner.registerInitialCondition("The building started with spaces.")


    # echo the new space's name back to the user
    runner.registerInfo("Space was added.")

    # report final condition of model
    runner.registerFinalCondition("The building finished with spaces.")

    return true
  end
end

# register the measure to be used by the application
AddZoneMixing.new.registerWithApplication
