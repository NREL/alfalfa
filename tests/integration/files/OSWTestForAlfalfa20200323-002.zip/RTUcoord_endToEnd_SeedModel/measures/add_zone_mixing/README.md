

###### (Automatically generated documentation)

# Add Zone Mixing 

## Description
Add Zone Mixing between two zones

## Modeler Description
Adds two zone mixing objects - one for each specified zone with same schedule and flow

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Zone 1

**Name:** zone1_name,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Zone 2

**Name:** zone2_name,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Schedule Name for Zone Mixing

**Name:** schedule_name,
**Type:** String,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Design Level for Zone Mixing

**Name:** design_level,
**Type:** Double,
**Units:** cfm,
**Required:** true,
**Model Dependent:** false




