

###### (Automatically generated documentation)

# RTU Coordination Final

## Description
RTU Coordination final copy to be used during experimentation in FY2020 project

## Modeler Description
Fill this in later

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Export to BCVTB?
Export will set all exportToBCVTB flags to true
**Name:** export_option,
**Type:** Boolean,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Real RTU in Lab
Select which RTU will be real.
**Name:** rtu_selected,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false




