# insert your copyright here

# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class RTUCoordinationJan2020 < OpenStudio::Measure::ModelMeasure
  # human readable name
  def name
    return "RTU Coordination Jan 2020"
  end
  # human readable description
  def description
    return "Fill this in later"
  end
  # human readable description of modeling approach
  def modeler_description
    return "Fill this in later"
  end
  # define the arguments that the user will input
  def arguments(model)
    args = OpenStudio::Measure::OSArgumentVector.new

    # populate choice argument for air loops in the model
    air_loop_handles = OpenStudio::StringVector.new
    air_loop_display_names = OpenStudio::StringVector.new

    # putting air loop names into hash
    air_loop_args = model.getAirLoopHVACs
    air_loop_args_hash = {}
    air_loop_args.each do |air_loop_arg|
        air_loop_args_hash[air_loop_arg.name.to_s] = air_loop_arg
    end

    # looping through sorted hash of air loops
    air_loop_args_hash.sort.map do |air_loop_name,air_loop|
        air_loop_handles << air_loop.handle.to_s
        air_loop_display_names << air_loop_name
    end

    # Local test or Export to BCVTB?
    export_option = OpenStudio::Measure::OSArgument.makeBoolArgument('export_option', true, false)
    export_option.setDisplayName('Export to BCVTB?')
    export_option.setDescription("Export will set all exportToBCVTB flags to true")
    export_option.setDefaultValue(false)
    args << export_option

    # Select which RTU will be overridden by real RTU in lab
    rtu_selected = OpenStudio::Measure::OSArgument.makeChoiceArgument('rtu_selected', air_loop_handles, air_loop_display_names, true)
    rtu_selected.setDisplayName('Real RTU in Lab')
    rtu_selected.setDescription('Select which RTU will be real.')
    args << rtu_selected

    return args
  end

  # define what happens when the measure is run
  def run(model, runner, user_arguments)
    super(model, runner, user_arguments)

    # use the built-in error checking
    if !runner.validateUserArguments(arguments(model), user_arguments)
      return false
    end

    # assign the user inputs to variables
    export_option = runner.getBoolArgumentValue('export_option', user_arguments)
    rtu_selected = runner.getOptionalWorkspaceObjectChoiceValue('rtu_selected', user_arguments, model)

    # Check AirLoop selection
    real_rtu = nil
    if not rtu_selected.get.to_AirLoopHVAC.empty?
        real_rtu = rtu_selected.get.to_AirLoopHVAC.get
    end

#-------

    ###--- START Model Object Section ---###

    # Create and add an OtherEquipment object to the ThermalZone for the selected RTU. This object will get passed the real RTU
    # electric meter data.
    thermal_zones_on_real_rtu = real_rtu.thermalZones()
    # apply the OtherEquipment object to the first thermal zone. The experiment set up implies only one thermal zone per RTU, but
    # just adding in some functionality for potential future use cases or adjustments.
    thermal_zone_selected = thermal_zones_on_real_rtu[0]

    # create OtherEquipmentDefinition object for Total RTU Power
    other_equipment_def_rtu_power = OpenStudio::Model::OtherEquipmentDefinition.new(model)
    other_equipment_def_rtu_power.setName("Other Equipment Definition RTU Power no Fan")
    other_equipment_def_rtu_power.setDesignLevelCalculationMethod("EquipmentLevel",0,0)
    other_equipment_def_rtu_power.setDesignLevel(1)
    other_equipment_def_rtu_power.setFractionLatent(0)
    other_equipment_def_rtu_power.setFractionRadiant(0)
    other_equipment_def_rtu_power.setFractionLost(1)

    # create OtherEquipment object for Total RTU Power
    other_equipment_rtu_power = OpenStudio::Model::OtherEquipment.new(other_equipment_def_rtu_power)
    other_equipment_rtu_power.setName("Other Equipment RTU Power no Fan")
    other_equipment_rtu_power.setFuelType("Electricity")
    other_equipment_rtu_power.setEndUseSubcategory("Real RTU Power")
    other_equipment_sch = OpenStudio::Model::ScheduleConstant.new(model)
    other_equipment_sch.setName("Real RTU OtherEquipment Schedule")
    other_equipment_sch.setValue(1)
    other_equipment_rtu_power.setSchedule(other_equipment_sch)
    other_equipment_rtu_power.setOtherEquipmentDefinition(other_equipment_def_rtu_power)

    # create OtherEquipmentDefinition object for Fan Power
    other_equipment_def_fan_power = OpenStudio::Model::OtherEquipmentDefinition.new(model)
    other_equipment_def_fan_power.setName("Other Equipment Definition Fan Power")
    other_equipment_def_fan_power.setDesignLevelCalculationMethod("EquipmentLevel",0,0)
    other_equipment_def_fan_power.setDesignLevel(1)
    other_equipment_def_fan_power.setFractionLatent(0)
    other_equipment_def_fan_power.setFractionRadiant(0)
    other_equipment_def_fan_power.setFractionLost(1)

    # create OtherEquipment object for Fan Power
    other_equipment_fan_power = OpenStudio::Model::OtherEquipment.new(other_equipment_def_fan_power)
    other_equipment_fan_power.setName("Other Equipment Fan Power")
    other_equipment_fan_power.setFuelType("Electricity")
    other_equipment_fan_power.setEndUseSubcategory("Real Fan Power")
    other_equipment_fan_power.setSchedule(other_equipment_sch)
    other_equipment_fan_power.setOtherEquipmentDefinition(other_equipment_def_fan_power)

    # add OtherEquipment object to Space
    spaces_on_thermal_zone = thermal_zone_selected.spaces()
    spaces_selected = spaces_on_thermal_zone[0]
    other_equipment_rtu_power.setSpace(spaces_selected)
    other_equipment_fan_power.setSpace(spaces_selected)

    ###--- END Model Object Section ---###

#-------

    ###--- START EMS and ExternalInterface Section ---###

    output_EMS = model.getOutputEnergyManagementSystem
    output_EMS.setActuatorAvailabilityDictionaryReporting("Verbose")
    output_EMS.setInternalVariableAvailabilityDictionaryReporting("Verbose")
    output_EMS.setEMSRuntimeLanguageDebugOutputLevel("None")

    # Create Site/Environmental Control Points
    # For now these are likely all READ Only points
    # Site Outdoor Air Drybulb Temperature
       # EMS Sensor - for internal use
       ems_sensor_site_drybulb = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Site Outdoor Air Drybulb Temperature")
       ems_sensor_site_drybulb.setName("Site_Drybulb_EMS_Sensor")
       ems_sensor_site_drybulb.setKeyName("*")

       # Output Variable - for external interface
       output_var_site_drybulb = OpenStudio::Model::OutputVariable.new("Site Outdoor Air Drybulb Temperature", model)
       output_var_site_drybulb.setName("Site_Drybulb_Temperature")
       output_var_site_drybulb.setReportingFrequency("timestep")
       output_var_site_drybulb.setKeyValue("*")
       output_var_site_drybulb.setExportToBCVTB(export_option)

    # Site Outdoor Air Dewpoint Temperature
       # EMS Sensor - for internal use
       ems_sensor_site_wetbulb = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Site Outdoor Air Wetbulb Temperature")
       ems_sensor_site_wetbulb.setName("Site_Wetbulb_EMS_Sensor")
       ems_sensor_site_wetbulb.setKeyName("*")

       # Output Variable - for external interface
       output_var_site_wetbulb = OpenStudio::Model::OutputVariable.new("Site Outdoor Air Wetbulb Temperature", model)
       output_var_site_wetbulb.setName("Site_Wetbulb_Temperature")
       output_var_site_wetbulb.setReportingFrequency("timestep")
       output_var_site_wetbulb.setKeyValue("*")
       output_var_site_wetbulb.setExportToBCVTB(export_option)

     # Site Direct Solar Radiation Rate per Area
       # EMS Sensor - for internal use
       ems_sensor_site_direct_rad = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Site Direct Solar Radiation Rate per Area")
       ems_sensor_site_direct_rad.setName("Site_Direct_Radiation_EMS_Sensor")
       ems_sensor_site_direct_rad.setKeyName("*")

       # Output Variable - for external interface
       output_var_site_direct_rad = OpenStudio::Model::OutputVariable.new("Site Direct Solar Radiation Rate per Area", model)
       output_var_site_direct_rad.setName("Site_Direct_Radiation")
       output_var_site_direct_rad.setReportingFrequency("timestep")
       output_var_site_direct_rad.setKeyValue("*")
       output_var_site_direct_rad.setExportToBCVTB(export_option)

     # Site Diffuse Solar Radiation Rate per Area
       # EMS Sensor - for internal use
       ems_sensor_site_diffuse_rad = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Site Diffuse Solar Radiation Rate per Area")
       ems_sensor_site_diffuse_rad.setName("Site_Diffuse_Radiation_EMS_Sensor")
       ems_sensor_site_diffuse_rad.setKeyName("*")

       # Output Variable - for external interface
       output_var_site_diffuse_rad = OpenStudio::Model::OutputVariable.new("Site Diffuse Solar Radiation Rate per Area", model)
       output_var_site_diffuse_rad.setName("Site_Diffuse_Radiation")
       output_var_site_diffuse_rad.setReportingFrequency("timestep")
       output_var_site_diffuse_rad.setKeyValue("*")
       output_var_site_diffuse_rad.setExportToBCVTB(export_option)

    # Create Control Points for Zones
    # EMS Sensors are for internal use only.
    # Output Variables will be flagged true for export to BCVTB so that Haystack measure can add the appropriate External
    # Interface Variables and Haystack points with tags for use with hardware in the loop.
    model.getThermalZones.each do |thermalZone|
        if not thermalZone.canBePlenum() #exclude plenum zones for this

         ## Zone Thermostat Air Temperature
            # EMS Sensor - for internal use
            ems_sensor_zn_temp = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Zone Thermostat Air Temperature")
            ems_sensor_zn_temp.setName("#{thermalZone.name.to_s.gsub(' ','_')}_Temp_EMS_Sensor")
            ems_sensor_zn_temp.setKeyName("#{thermalZone.name.to_s}")

            # Output Variable - for external interface
            output_var_zn_temp = OpenStudio::Model::OutputVariable.new("Zone Thermostat Air Temperature",model)
            output_var_zn_temp.setName("#{thermalZone.name.to_s.gsub(' ','_')}_Thermostat_Air_Temperature")
            output_var_zn_temp.setReportingFrequency("timestep")
            output_var_zn_temp.setKeyValue("#{thermalZone.name.to_s}")
            output_var_zn_temp.setExportToBCVTB(export_option)

### Cooling Setpoints will be READ only for January test
         ## Zone Thermostat Cooling Setpoint Temperature
            # EMS Sensor - for internal use
#            ems_sensor_zn_tempSP = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Zone Thermostat Cooling Setpoint Temperature")
#            ems_sensor_zn_tempSP.setName("#{thermalZone.name.to_s.gsub(' ','_')}_CoolSP_EMS_Sensor")
#            ems_sensor_zn_tempSP.setKeyName("#{thermalZone.name.to_s}")

            # EMS Actuator - for internal use
#            ems_actuator_zn_tempSP = OpenStudio::Model::EnergyManagementSystemActuator.new(thermalZone, "Zone Temperature Control", "Cooling Setpoint")
#            ems_actuator_zn_tempSP.setName("#{thermalZone.name.to_s.gsub(' ','_')}_CoolSP_EMS_Actuator")

            # Global Variables - for external use
#            ems_GV_zn_tempSP = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{thermalZone.name.to_s.gsub(' ','_')}_Cooling_Setpoint")
#            ems_GV_zn_tempSP.setName("#{thermalZone.name.to_s.gsub(' ','_')}_Cooling_Setpoint")
#            if export_option
#              ems_GV_zn_tempSP.setExportToBCVTB(export_option)
#            end

#            ems_GV_zn_tempSP_enable = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{thermalZone.name.to_s.gsub(' ','_')}_Cooling_Setpoint_Enable")
#            ems_GV_zn_tempSP_enable.setName("#{thermalZone.name.to_s.gsub(' ','_')}_Cooling_Setpoint_Enable")
#            if export_option
#              ems_GV_zn_tempSP_enable.setExportToBCVTB(export_option)
#            end

            # Create Cooling Setpoint EMS Program and Calling Manager
#            ems_program_zn_tempSP = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
#            ems_program_zn_tempSP.setName("#{thermalZone.name.to_s.gsub(' ','_')}_Set_Cooling_Setpoint")
#            ems_program_zn_tempSP_body = <<-EMS

#                IF #{thermalZone.name.to_s.gsub(' ','_')}_Cooling_Setpoint_Enable == 1
#                    SET #{ems_actuator_zn_tempSP.handle.to_s} = #{thermalZone.name.to_s.gsub(' ','_')}_Cooling_Setpoint
#                ELSE,
#                    SET #{ems_actuator_zn_tempSP.handle.to_s} = Null
#                ENDIF,

#            EMS
#            ems_program_zn_tempSP.setBody(ems_program_zn_tempSP_body)

#            ems_program_zn_tempSP_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
#            ems_program_zn_tempSP_callingMgr.setName("#{thermalZone.name.to_s.gsub(' ','_')}_Set_Cooling_Setpoint_CallingMgr")
#            ems_program_zn_tempSP_callingMgr.setCallingPoint("BeginZoneTimestepBeforeInitHeatBalance")
#            ems_program_zn_tempSP_callingMgr.addProgram(ems_program_zn_tempSP)

         ## Zone Air Relative Humidity
            # EMS Sensor - for internal use
            ems_sensor_zn_RH = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Zone Air Relative Humidity")
            ems_sensor_zn_RH.setName("#{thermalZone.name.to_s.gsub(' ','_')}_RH_EMS_Sensor")
            ems_sensor_zn_RH.setKeyName("#{thermalZone.name.to_s}")

            # Output Variable - for external interface
            output_var_zn_RH = OpenStudio::Model::OutputVariable.new("Zone Air Relative Humidity",model)
            output_var_zn_RH.setName("#{thermalZone.name.to_s.gsub(' ','_')}_Relative_Humidity")
            output_var_zn_RH.setReportingFrequency("timestep")
            output_var_zn_RH.setKeyValue("#{thermalZone.name.to_s}")
            output_var_zn_RH.setExportToBCVTB(export_option)

            runner.registerInfo("EMS Sensor created for Zone Thermostat Air Temperature in #{thermalZone.name.to_s}")
            if export_option
                runner.registerInfo("Output Variable created for Zone Thermostat Air Temperature for #{thermalZone.name.to_s} and flagged export to BCVTB")
            end
        end
    end

    # Create Control Points for RTUs
    # Create Read Points for Return Air, Outdoor Air, and Mixed Air Drybulb and Wetbulb Temperatures
    model.getAirLoopHVACs.each do |airloop|
      if not airloop.returnAirNode.empty?
        returnAirNode = airloop.returnAirNode.get

        ems_sensor_ra_drybulb = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "System Node Temperature")
        ems_sensor_ra_drybulb.setName("#{airloop.name.to_s.gsub(' ','_')}_RA_Drybulb_EMS_Sensor")
        ems_sensor_ra_drybulb.setKeyName("#{returnAirNode.name.to_s}")

        runner.registerInfo("EMS Sensor create for Return Air Temperature at #{returnAirNode.name.to_s}")

        output_var_ra_drybulb = OpenStudio::Model::OutputVariable.new("System Node Temperature", model)
        output_var_ra_drybulb.setName("#{airloop.name.to_s.gsub(' ','_')}_RA_Drybulb_Temperature")
        output_var_ra_drybulb.setReportingFrequency("timestep")
        output_var_ra_drybulb.setKeyValue("#{returnAirNode.name.to_s}")
        output_var_ra_drybulb.setExportToBCVTB(export_option)

        if export_option
            runner.registerInfo("Output Variable created for Return Air Temperature and flagged export to BCVTB")
        end

        ems_sensor_ra_wetbulb = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "System Node Wetbulb Temperature")
        ems_sensor_ra_wetbulb.setName("#{airloop.name.to_s.gsub(' ','_')}_RA_Wetbulb_EMS_Sensor")
        ems_sensor_ra_wetbulb.setKeyName("#{returnAirNode.name.to_s}")

        runner.registerInfo("EMS Sensor create for Return Air Wetbulb Temperature at #{returnAirNode.name.to_s}")

        output_var_ra_wetbulb = OpenStudio::Model::OutputVariable.new("System Node Wetbulb Temperature", model)
        output_var_ra_wetbulb.setName("#{airloop.name.to_s.gsub(' ','_')}_RA_Wetbulb_Temperature")
        output_var_ra_wetbulb.setReportingFrequency("timestep")
        output_var_ra_wetbulb.setKeyValue("#{returnAirNode.name.to_s}")
        output_var_ra_wetbulb.setExportToBCVTB(export_option)

        if export_option
            runner.registerInfo("Output Variable created for Return Air Wetbulb Temperature and flagged export to BCVTB")
        end
      end

    if not airloop.outdoorAirNode.empty?
      outdoorAirNode = airloop.outdoorAirNode.get

      ems_sensor_oa_drybulb = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "System Node Temperature")
      ems_sensor_oa_drybulb.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Drybulb_EMS_Sensor")
      ems_sensor_oa_drybulb.setKeyName("#{outdoorAirNode.name.to_s}")

      runner.registerInfo("EMS Sensor create for Outdoor Air Temperature at #{outdoorAirNode.name.to_s}")

      #output_var_oa_drybulb = OpenStudio::Model::OutputVariable.new("System Node Temperature", model)
      #output_var_oa_drybulb.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Drybulb_Temperature")
      #output_var_oa_drybulb.setReportingFrequency("timestep")
      #output_var_oa_drybulb.setKeyValue("#{outdoorAirNode.name.to_s}")
      #output_var_oa_drybulb.setExportToBCVTB(export_option)

      #if export_option
      #    runner.registerInfo("Output Variable created for Outdoor Air Temperature and flagged export to BCVTB")
      #end

      ems_sensor_oa_wetbulb = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "System Node Wetbulb Temperature")
      ems_sensor_oa_wetbulb.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Wetbulb_EMS_Sensor")
      ems_sensor_oa_wetbulb.setKeyName("#{outdoorAirNode.name.to_s}")

      runner.registerInfo("EMS Sensor create for Outdoor Air Wetbulb Temperature at #{outdoorAirNode.name.to_s}")

      #output_var_oa_wetbulb = OpenStudio::Model::OutputVariable.new("System Node Wetbulb Temperature", model)
      #output_var_oa_wetbulb.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Wetbulb_Temperature")
      #output_var_oa_wetbulb.setReportingFrequency("timestep")
      #output_var_oa_wetbulb.setKeyValue("#{outdoorAirNode.name.to_s}")
      #output_var_oa_wetbulb.setExportToBCVTB(export_option)

      #if export_option
      #    runner.registerInfo("Output Variable created for Outdoor Air Wetbulb Temperature and flagged export to BCVTB")
      #end
    end

    if not airloop.mixedAirNode.empty?
      mixedAirNode = airloop.mixedAirNode.get

      ems_sensor_ma_drybulb = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "System Node Temperature")
      ems_sensor_ma_drybulb.setName("#{airloop.name.to_s.gsub(' ','_')}_MA_Drybulb_EMS_Sensor")
      ems_sensor_ma_drybulb.setKeyName("#{mixedAirNode.name.to_s}")

      runner.registerInfo("EMS Sensor create for Mixed Air Temperature at #{mixedAirNode.name.to_s}")

      output_var_ma_drybulb = OpenStudio::Model::OutputVariable.new("System Node Temperature", model)
      output_var_ma_drybulb.setName("#{airloop.name.to_s.gsub(' ','_')}_MA_Drybulb_Temperature")
      output_var_ma_drybulb.setReportingFrequency("timestep")
      output_var_ma_drybulb.setKeyValue("#{mixedAirNode.name.to_s}")
      output_var_ma_drybulb.setExportToBCVTB(export_option)

      if export_option
          runner.registerInfo("Output Variable created for Mixed Air Temperature and flagged export to BCVTB")
      end

      ems_sensor_ma_wetbulb = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "System Node Wetbulb Temperature")
      ems_sensor_ma_wetbulb.setName("#{airloop.name.to_s.gsub(' ','_')}_MA_Wetbulb_EMS_Sensor")
      ems_sensor_ma_wetbulb.setKeyName("#{mixedAirNode.name.to_s}")

      runner.registerInfo("EMS Sensor create for Mixed Air Wetbulb Temperature at #{mixedAirNode.name.to_s}")

      output_var_ma_wetbulb = OpenStudio::Model::OutputVariable.new("System Node Wetbulb Temperature", model)
      output_var_ma_wetbulb.setName("#{airloop.name.to_s.gsub(' ','_')}_MA_Wetbulb_Temperature")
      output_var_ma_wetbulb.setReportingFrequency("timestep")
      output_var_ma_wetbulb.setKeyValue("#{mixedAirNode.name.to_s}")
      output_var_ma_wetbulb.setExportToBCVTB(export_option)

      if export_option
          runner.registerInfo("Output Variable created for Mixed Air Wetbulb Temperature and flagged export to BCVTB")
      end
    end

### For January this will be a READ only point
    # Create OA Damper Postion Read and Write points
    # EMS Sensor - internal use
    ems_sensor_oa_damper_position = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Air System Outdoor Air Flow Fraction")
    ems_sensor_oa_damper_position.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Damper_Position_EMS_Sensor")
    ems_sensor_oa_damper_position.setKeyName("#{airloop.name.to_s}")

    runner.registerInfo("EMS Sensor created for Outdoor Air Damper Position on #{airloop.name.to_s}")

    # Output Variable - external use
    output_var_oa_damper_position = OpenStudio::Model::OutputVariable.new("Air System Outdoor Air Flow Fraction", model)
    output_var_oa_damper_position.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Damper_Position_Read")
    output_var_oa_damper_position.setReportingFrequency("timestep")
    output_var_oa_damper_position.setKeyValue("#{airloop.name.to_s}")
    output_var_oa_damper_position.setExportToBCVTB(export_option)

    if export_option
      runner.registerInfo("Output Variable created for Outdoor Air Damper Position and flagged export to BCVTB")
    end

    #EMS Actuator - NOTE: actuate flow rate NOT damper position
#    if not airloop.outdoorAirNode.empty?
#      outdoorAirNode = airloop.outdoorAirNode.get
#      ems_actuator_oa_massflow = OpenStudio::Model::EnergyManagementSystemActuator.new(outdoorAirNode, "System Node Setpoint", "Mass Flow Rate Setpoint")
#      ems_actuator_oa_massflow.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_MassFlow_EMS_Actuator")
#    end

    #EMS Internal Variable - internal use to convert between flow rates and fractional flow rates
#    if not airloop.airLoopHVACOutdoorAirSystem.empty?
#      airloopHVACOASystem = airloop.airLoopHVACOutdoorAirSystem.get
#      oaController = airloopHVACOASystem.getControllerOutdoorAir

#      ems_IV_oa_maxflowrate = OpenStudio::Model::EnergyManagementSystemInternalVariable.new(model, " #{airloop.name.to_s} Outdoor Air Controller Maximum Mass Flow Rate")
#      ems_IV_oa_maxflowrate.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Max_Flow")
#      ems_IV_oa_maxflowrate.setInternalDataIndexKeyName("#{oaController.name.to_s}")
#      ems_IV_oa_maxflowrate.setInternalDataType("Outdoor Air Controller Maximum Mass Flow Rate")
#    end

    #EMS Global Variables - External Use
#    ems_GV_oa_damper_position = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{airloop.name.to_s.gsub(' ','_')}_OA_Damper_Position_Write")
#    ems_GV_oa_damper_position.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Damper_Position_Write")
#    if export_option
#      ems_GV_oa_damper_position.setExportToBCVTB(export_option)
#    end

#    ems_GV_oa_damper_position_enable = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{airloop.name.to_s.gsub(' ','_')}_OA_Damper_Position_Write_Enable")
#    ems_GV_oa_damper_position_enable.setName("#{airloop.name.to_s.gsub(' ','_')}_OA_Damper_Position_Write_Enable")
#    if export_option
#      ems_GV_oa_damper_position_enable_enable.setExportToBCVTB(export_option)
#    end

    # Create OA Danmper Position EMS Program and Calling Manager
    # This program will read in fractional OA famper position and convert to mass flow on system node point
#    ems_program_oa_damper_position = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
#    ems_program_oa_damper_position.setName("#{airloop.name.to_s.gsub(' ','_')}_Set_OA_Damper_Position")
#    ems_program_oa_damper_position_body = <<-EMS

#        IF #{airloop.name.to_s.gsub(' ','_')}_OA_Damper_Position_Write_Enable == 1
#            SET #{ems_actuator_oa_massflow.handle.to_s} = #{airloop.name.to_s.gsub(' ','_')}_OA_Damper_Position_Write * #{ems_IV_oa_maxflowrate.name.to_s}
#        ELSE,
#            SET #{ems_actuator_oa_massflow.handle.to_s} = Null
#        ENDIF,

#    EMS
#    ems_program_oa_damper_position.setBody(ems_program_oa_damper_position_body)

#    ems_program_oa_damper_position_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
#    ems_program_oa_damper_position_callingMgr.setName("#{airloop.name.to_s.gsub(' ','_')}_Set_OA_Damper_Position_CallingMgr")
#    ems_program_oa_damper_position_callingMgr.setCallingPoint("AfterPredictorAfterHVACManagers")
#    ems_program_oa_damper_position_callingMgr.addProgram(ems_program_oa_damper_position)

    # Create Fan Fractional Flow Rate Read and Write Points
    # EMS will actuate actual mass flow rate on the fan, but expose fractional flow rates
    if not airloop.supplyFan.empty?
      supplyFan = airloop.supplyFan.get

      # EMS Internal Variable - internal use to convert between flow rates and fractional flow rates
      ems_IV_fan_maxflowrate = OpenStudio::Model::EnergyManagementSystemInternalVariable.new(model, "#{airloop.name.to_s} Fan Maximum Mass Flow Rate")
      ems_IV_fan_maxflowrate.setName("#{airloop.name.to_s.gsub(' ','_')}_Fan_Max_Flow")
      ems_IV_fan_maxflowrate.setInternalDataIndexKeyName("#{supplyFan.name.to_s}")
      ems_IV_fan_maxflowrate.setInternalDataType("Fan Maximum Mass Flow Rate")

      # EMS Senssor - Internal use
      ems_sensor_fan_massflow = OpenStudio::Model::EnergyManagementSystemSensor.new(model, "Fan Air Mass Flow Rate")
      ems_sensor_fan_massflow.setName("#{airloop.name.to_s.gsub(' ','_')}_Fan_MassFlow_EMS_Sensor")
      ems_sensor_fan_massflow.setKeyName("#{supplyFan.name.to_s}")

      runner.registerInfo("EMS Sensor create for Supply Fan Mass Flow on #{airloop.name.to_s}")

      # EMS Program to calculate fan fraction flow and pass it to an EnergyManagementSystemOutputVariable
      ems_program_calc_fractionflow = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
      ems_program_calc_fractionflow.setName("#{airloop.name.to_s.gsub(' ','_')}_Calc_Fan_FractionFlow")
      ems_program_calc_fractionflow_body = <<-EMS

          SET CalcFlowFraction = #{ems_sensor_fan_massflow.name.to_s.gsub(' ','_')}/#{ems_IV_fan_maxflowrate.name.to_s}

      EMS
      ems_program_calc_fractionflow.setBody(ems_program_calc_fractionflow_body)

      # EMS Program Calling Manager to calculate fan fraction flwo rate and export to experimeent
      ems_program_calc_fractionfow_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
      ems_program_calc_fractionfow_callingMgr.setName("#{airloop.name.to_s.gsub(' ','_')}_Calc_Fan_FractionFlow_CallingMgr")
      ems_program_calc_fractionfow_callingMgr.setCallingPoint("BeginZoneTimestepBeforeInitHeatBalance")
      ems_program_calc_fractionfow_callingMgr.addProgram(ems_program_calc_fractionflow)

      # EMS Output Variable - External use
      # Created in lieu of standard output variable to expose fan fractional flow rate in lieu of fan mass flow rate
      ems_output_var_fan_fractionflow = OpenStudio::Model::EnergyManagementSystemOutputVariable.new(model, "CalcFlowFraction")
      ems_output_var_fan_fractionflow.setName("#{airloop.name.to_s.gsub(' ', '_')}_Fan_FractionFlow")
      ems_output_var_fan_fractionflow.setEMSVariableName("CalcFlowFraction")
      ems_output_var_fan_fractionflow.setTypeOfDataInVariable("Averaged")
      ems_output_var_fan_fractionflow.setUpdateFrequency("SystemTimestep")
      ems_output_var_fan_fractionflow.setEMSProgramOrSubroutineName(ems_program_calc_fractionflow)
      if export_option
        ems_output_var_fan_fractionflow.setExportToBCVTB(export_option)
      end

### For January  this will be a READ only point (And maybe in the future)
#      ems_actuator_fan_massflow = OpenStudio::Model::EnergyManagementSystemActuator.new(supplyFan, "Fan", "Fan Air Mass Flow Rate")
#      ems_actuator_fan_massflow.setName("#{airloop.name.to_s.gsub(' ','_')}_Fan_MassFlow_EMS_Actuator")

      # EMS GV - for fractional flow
#      ems_GV_fan_fractionflow = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{airloop.name.to_s.gsub(' ','_')}_Fan_FractionFlow")
#      ems_GV_fan_fractionflow.setName("#{airloop.name.to_s.gsub(' ','_')}_Fan_FractionFlow")
#      if export_option
#        ems_GV_fan_fractionflow.setExportToBCVTB(export_option)
#      end

#      ems_GV_fan_fraction_enable = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{airloop.name.to_s.gsub(' ','_')}_Fan_FractionFlow_Enable")
#      ems_GV_fan_fraction_enable.setName("#{airloop.name.to_s.gsub(' ','_')}_Fan_FractionFlow_Enable")
#      if export_option
#        ems_GV_fan_fraction_enable.setExportToBCVTB(export_option)
#      end

      # Create Fan Mass Flow EMS Program and Calling Manager
#      ems_program_fan_massflow = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
#      ems_program_fan_massflow.setName("#{airloop.name.to_s.gsub(' ','_')}_Set_Fan_Mass_Flow_Rate")
#      ems_program_fan_massflow_body = <<-EMS

#          IF #{airloop.name.to_s.gsub(' ','_')}_Fan_FractionFlow_Enable == 1
#              SET #{ems_actuator_fan_massflow.handle.to_s} = #{airloop.name.to_s.gsub(' ','_')}_Fan_FractionFlow * #{ems_IV_fan_maxflowrate.name.to_s}
#          ELSE,
#              SET #{ems_actuator_fan_massflow.handle.to_s} = Null
#          ENDIF,

#      EMS
#      ems_program_fan_massflow.setBody(ems_program_fan_massflow_body)

#      ems_program_fan_massflow_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
#      ems_program_fan_massflow_callingMgr.setName("#{airloop.name.to_s.gsub(' ','_')}_Set_Fan_Mass_Flow_Rate_CallingMgr")
#      ems_program_fan_massflow_callingMgr.setCallingPoint("AfterPredictorAfterHVACManagers")
#      ems_program_fan_massflow_callingMgr.addProgram(ems_program_fan_massflow)

      # Zero out power curve for the selected real RTU fan
      if airloop == real_rtu
        if not supplyFan.to_FanVariableVolume.empty?
          supplyFan = supplyFan.to_FanVariableVolume.get
          supplyFan.setFanPowerCoefficient1(0.0)
          supplyFan.setFanPowerCoefficient2(0.0)
          supplyFan.setFanPowerCoefficient3(0.0)
          supplyFan.setFanPowerCoefficient4(0.0)
          supplyFan.setFanPowerCoefficient5(0.0)
        end

        # Zero out EIRfFF curve for the selected real RTU cooling coil object
        new_zero_cc_curve = OpenStudio::Model::CurveQuadratic.new(model)
        new_zero_cc_curve.setCoefficient1Constant(0.0)
        new_zero_cc_curve.setCoefficient2x(0.0)
        new_zero_cc_curve.setCoefficient3xPOW2(0.0)
        new_zero_cc_curve.setMinimumValueofx(0.0)
        new_zero_cc_curve.setMaximumValueofx(1.0)

        airloop.supplyComponents.each do |sc|
          if sc.to_CoilCoolingDXSingleSpeed.is_initialized
                cc = sc.to_CoilCoolingDXSingleSpeed.get
                cc.setEnergyInputRatioFunctionOfFlowFractionCurve(new_zero_cc_curve)
          end
        end
      end

### This is primarily being written for the January test, but hopefully most can be resused as part of the future RTU coordination experiements
      # This Section is going to create control over whether or not each RTU is in Cooling Mode
      # There is going to be an External Variable for each RTU that is Cooling ON or Cooling OFF
      # An internal EMS program will take in this writable point and set the cooling coil outlet air node to an appropriate setpoint so that the
      # cooling coil will turn on or off.

      # EMS Global Variables to be exposed and used to control Cooling Mode (ON/OFF) for each RTU in model
      ems_GV_cooling_mode = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{airloop.name.to_s.gsub(' ','_')}_Cooling_Mode")
      ems_GV_cooling_mode.setName("#{airloop.name.to_s.gsub(' ','_')}_Cooling_Mode")
      if export_option
        ems_GV_cooling_mode.setExportToBCVTB(export_option)
      end

      ems_GV_cooling_mode_enable = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{airloop.name.to_s.gsub(' ','_')}_Cooling_Mode_Enable")
      ems_GV_cooling_mode_enable.setName("#{airloop.name.to_s.gsub(' ','_')}_Cooling_Mode_Enable")
      if export_option
        ems_GV_cooling_mode_enable.setExportToBCVTB(export_option)
      end

      if airloop == real_rtu
        # EMS Global Variables to be exposed and used to control Real RTU SA conditions
        ems_GV_real_rtu_sa_drybulb = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{airloop.name.to_s.gsub(' ','_')}_Real_RTU_SA_Drybulb")
        ems_GV_real_rtu_sa_drybulb.setName("#{airloop.name.to_s.gsub(' ','_')}_Real_RTU_SA_Drybulb")
        if export_option
          ems_GV_real_rtu_sa_drybulb.setExportToBCVTB(export_option)
        end

        ems_GV_real_rtu_sa_drybulb_enable = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "#{airloop.name.to_s.gsub(' ','_')}_Real_RTU_SA_Drybulb_Enable")
        ems_GV_real_rtu_sa_drybulb_enable.setName("#{airloop.name.to_s.gsub(' ','_')}_Real_RTU_SA_Drybulb_Enable")
        if export_option
          ems_GV_real_rtu_sa_drybulb_enable.setExportToBCVTB(export_option)
        end
      end

      #Supply Air Temperature and Humidity setpoints
      cc_outletNode = {}
      airloop.supplyComponents.each do |sc|
          if sc.to_CoilCoolingDXSingleSpeed.is_initialized
              cc = sc.to_CoilCoolingDXSingleSpeed.get
              if not cc.connectedObject(cc.outletPort).empty?
                  cc_outletNode = cc.connectedObject(cc.outletPort).get.to_Node.get
              end
          elsif sc.to_CoilCoolingDXTwoSpeed.is_initialized
              cc = sc.to_CoilCoolingDXTwoSpeed.get
              if not cc.connectedObject(cc.outletPort).empty?
                  cc_outletNode = cc.connectedObject(cc.outletPort).get.to_Node.get
              end
          end
      end

      ems_SA_temp_actuator = OpenStudio::Model::EnergyManagementSystemActuator.new(cc_outletNode, "System Node Setpoint", "Temperature Setpoint")
      ems_SA_temp_actuator.setName("#{airloop.name.to_s.gsub(' ','_')}_SA_Temp_EMS_Actuator")

      # Not likely going to use this at all for January Test
      ems_SA_humd_actuator = OpenStudio::Model::EnergyManagementSystemActuator.new(cc_outletNode, "System Node Setpoint", "Humidity Ratio Setpoint")
      ems_SA_humd_actuator.setName("#{airloop.name.to_s.gsub(' ','_')}_SA_HumidRatio_EMS_Actuator")

      # Create Output Variable for Confirmation ONLY
      output_var_SA_temp_for_confirmation = OpenStudio::Model::OutputVariable.new("System Node Temperature", model)
      output_var_SA_temp_for_confirmation.setName("Supply_Air_Temp_For_Confirmation")
      output_var_SA_temp_for_confirmation.setReportingFrequency("timestep")
      output_var_SA_temp_for_confirmation.setKeyValue("#{cc_outletNode.name.to_s}")
      output_var_SA_temp_for_confirmation.setExportToBCVTB(export_option)

      # Create Output Variable for Confirmation ONLY
      output_var_SA_temp_for_confirmation = OpenStudio::Model::OutputVariable.new("System Node Humidity Ratio", model)
      output_var_SA_temp_for_confirmation.setName("Supply_Air_Humidity_Ratio_For_Confirmation")
      output_var_SA_temp_for_confirmation.setReportingFrequency("timestep")
      output_var_SA_temp_for_confirmation.setKeyValue("#{cc_outletNode.name.to_s}")
      output_var_SA_temp_for_confirmation.setExportToBCVTB(export_option)

      # Two EMS programs exist to set SA Set_SA_Conditions
      # First EMS program is for Simulated RTUs. This program looks for the Cooling ON/OFF command and then sets SA dry bulb actuator.
      # Cooling ON yields 55 F temperature setpoint
      # Cooling OFF yields setting SA temperature equal to the MA tempterature
      # Second EMS program is for Real RTU. This program looks for the Cooling ON/OFF command as well, but sets SA conditions based on real RTU

      if airloop == real_rtu
        ems_program_SA_conditions = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
        ems_program_SA_conditions.setName("#{airloop.name.to_s.gsub(' ','_')}_Set_SA_Conditions")
        ems_program_SA_conditions_body = <<-EMS

          IF #{airloop.name.to_s.gsub(' ','_')}_Cooling_Mode_Enable == 1
             SET #{ems_SA_temp_actuator.handle.to_s} = #{airloop.name.to_s.gsub(' ','_')}_Real_RTU_SA_Drybulb
          ELSE,
             SET #{ems_SA_temp_actuator.handle.to_s} = #{airloop.name.to_s.gsub(' ','_')}_Real_RTU_SA_Drybulb
          ENDIF,

          EMS
        ems_program_SA_conditions.setBody(ems_program_SA_conditions_body)

        ems_program_SA_conditions_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
        ems_program_SA_conditions_callingMgr.setName("#{airloop.name.to_s.gsub(' ','_')}_Set_SA_Conditions_CallingMgr")
        ems_program_SA_conditions_callingMgr.setCallingPoint("AfterPredictorAfterHVACManagers")
        ems_program_SA_conditions_callingMgr.addProgram(ems_program_SA_conditions)

        ems_program_initialize_realRTU_SA_drybulb = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
        ems_program_initialize_realRTU_SA_drybulb.setName("#{airloop.name.to_s.gsub(' ','_')}_Initialize_RealRTU_SA_Program")
        ems_program_initialize_realRTU_SA_drybulb_body = <<-EMS

        SET #{ems_GV_real_rtu_sa_drybulb.handle.to_s} = 0
        SET #{ems_GV_real_rtu_sa_drybulb_enable.handle.to_s} = 0

        EMS
        ems_program_initialize_realRTU_SA_drybulb.setBody(ems_program_initialize_realRTU_SA_drybulb_body)

        ems_program_initilize_realRTU_SA_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
        ems_program_initilize_realRTU_SA_callingMgr.setName("#{airloop.name.to_s.gsub(' ','_')}_Initialize_RealRTU_SA_CallingMgr")
        ems_program_initilize_realRTU_SA_callingMgr.setCallingPoint("BeginNewEnvironment")
        ems_program_initilize_realRTU_SA_callingMgr.addProgram(ems_program_initialize_realRTU_SA_drybulb)
      elsif
        ems_program_SA_conditions = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
        ems_program_SA_conditions.setName("#{airloop.name.to_s.gsub(' ','_')}_Set_SA_Conditions")
        ems_program_SA_conditions_body = <<-EMS

          IF #{airloop.name.to_s.gsub(' ','_')}_Cooling_Mode_Enable == 1
            SET #{ems_SA_temp_actuator.handle.to_s} = 12.77777778
          ELSE,
            SET #{ems_SA_temp_actuator.handle.to_s} = #{airloop.name.to_s.gsub(' ','_')}_MA_Drybulb_EMS_Sensor
          ENDIF,

          EMS
        ems_program_SA_conditions.setBody(ems_program_SA_conditions_body)

        ems_program_SA_conditions_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
        ems_program_SA_conditions_callingMgr.setName("#{airloop.name.to_s.gsub(' ','_')}_Set_SA_Conditions_CallingMgr")
        ems_program_SA_conditions_callingMgr.setCallingPoint("AfterPredictorAfterHVACManagers")
        ems_program_SA_conditions_callingMgr.addProgram(ems_program_SA_conditions)
      end

      ems_program_initialize_coolingMode = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
      ems_program_initialize_coolingMode.setName("#{airloop.name.to_s.gsub(' ','_')}_Initialize_CoolingMode_Program")
      ems_program_initialize_coolingMode_body = <<-EMS

      SET #{ems_GV_cooling_mode.handle.to_s} = 0
      SET #{ems_GV_cooling_mode_enable.handle.to_s} = 0

      EMS
      ems_program_initialize_coolingMode.setBody(ems_program_initialize_coolingMode_body)

      ems_program_initilize_coolingMode_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
      ems_program_initilize_coolingMode_callingMgr.setName("#{airloop.name.to_s.gsub(' ','_')}_Initialize_CoolingMode_Program_CallingMgr")
      ems_program_initilize_coolingMode_callingMgr.setCallingPoint("BeginNewEnvironment")
      ems_program_initilize_coolingMode_callingMgr.addProgram(ems_program_initialize_coolingMode)
    end
  end
  # Real RTU Power Section
  # Create EMS Actuators and Global Variables on the OtherEquipment objects created above. These will take in the real electric power signals and inject that information back into the model with NO EFFECT on the thermal zone.
  # Fan first
  ems_actuator_otherEquip_fan_power = OpenStudio::Model::EnergyManagementSystemActuator.new(other_equipment_fan_power, "OtherEquipment", "Power Level")
  ems_actuator_otherEquip_fan_power.setName("#{other_equipment_fan_power.name.to_s.gsub(' ','_')}_Fan_Power_Actuator")

  ems_GV_fan_power = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "Real_RTU_Fan_Power")
  ems_GV_fan_power.setName("Real_RTU_Fan_Power")
  if export_option
    ems_GV_fan_power.setExportToBCVTB(export_option)
  end

  ems_GV_fan_power_enable = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "Real_RTU_Fan_Power_Enable")
  ems_GV_fan_power_enable.setName("Real_RTU_Fan_Power_Enable")
  if export_option
    ems_GV_fan_power_enable.setExportToBCVTB(export_option)
  end

  #####  # Output Variable for Confirmation ONLY
  output_var_fan_power_for_confirmation = OpenStudio::Model::OutputVariable.new("Other Equipment Electric Rate", model)
  output_var_fan_power_for_confirmation.setName("Fan_Power_Output_Variable_For_Confirmation")
  output_var_fan_power_for_confirmation.setReportingFrequency("timestep")
  output_var_fan_power_for_confirmation.setKeyValue("#{other_equipment_fan_power.name.to_s}")
  output_var_fan_power_for_confirmation.setExportToBCVTB(export_option)

  # Create Fan EMS Program and Calling Manager
  # This code will set the Global Variable created knowing that they Haystack measure will replace this object with the appropriate ExternalInterface objects.
  ems_program_write_fan_power = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
  ems_program_write_fan_power.setName("Write_Real_Fan_Power_to_OtherEquipment_Fan")
  ems_program_write_fan_power_body = <<-EMS

      IF Real_RTU_Fan_Power_Enable == 1
          SET #{ems_actuator_otherEquip_fan_power.handle.to_s} = Real_RTU_Fan_Power
      ELSE,
          SET #{ems_actuator_otherEquip_fan_power.handle.to_s} = 0
      ENDIF,

  EMS
  ems_program_write_fan_power.setBody(ems_program_write_fan_power_body)

  ems_program_write_fan_power_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
  ems_program_write_fan_power_callingMgr.setName("Write_Real_Fan_Power_to_OtherEquipment_Fan_CallingMgr")
  ems_program_write_fan_power_callingMgr.setCallingPoint("BeginZoneTimestepBeforeInitHeatBalance")
  ems_program_write_fan_power_callingMgr.addProgram(ems_program_write_fan_power)

  # Now Cooling Coil power
  ems_actuator_otherEquip_cc_power = OpenStudio::Model::EnergyManagementSystemActuator.new(other_equipment_rtu_power, "OtherEquipment", "Power Level")
  ems_actuator_otherEquip_cc_power.setName("#{other_equipment_rtu_power.name.to_s.gsub(' ','_')}_RTU_Power_Actuator")

  ems_GV_cc_power = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "Real_RTU_CoolingCoil_Power")
  ems_GV_cc_power.setName("Real_RTU_CoolingCoil_Power")
  if export_option
    ems_GV_cc_power.setExportToBCVTB(export_option)
  end

  ems_GV_cc_power_enable = OpenStudio::Model::EnergyManagementSystemGlobalVariable.new(model, "Real_RTU_CoolingCoil_Power_Enable")
  ems_GV_cc_power_enable.setName("Real_RTU_CoolingCoil_Power_Enable")
  if export_option
    ems_GV_cc_power_enable.setExportToBCVTB(export_option)
  end

  #####  # Output Variable for Confirmation ONLY
  output_var_rtu_power_for_confirmation = OpenStudio::Model::OutputVariable.new("Other Equipment Electric Rate", model)
  output_var_rtu_power_for_confirmation.setName("RTU_Power_Output_Variable_For_Confirmation")
  output_var_rtu_power_for_confirmation.setReportingFrequency("timestep")
  output_var_rtu_power_for_confirmation.setKeyValue("#{other_equipment_rtu_power.name.to_s}")
  output_var_rtu_power_for_confirmation.setExportToBCVTB(export_option)

  # Create Fan EMS Program and Calling Manager
  # This code will set the Global Variable created knowing that they Haystack measure will replace this object with the appropriate ExternalInterface objects.
  ems_program_write_cc_power = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
  ems_program_write_cc_power.setName("Write_Real_RTU_CC_Power_to_OtherEquipment_RTU")
  ems_program_write_cc_power_body = <<-EMS

      IF Real_RTU_CoolingCoil_Power_Enable == 1
      SET #{ems_actuator_otherEquip_cc_power.handle.to_s} = Real_RTU_CoolingCoil_Power - Real_RTU_Fan_Power
      ELSE,
          SET #{ems_actuator_otherEquip_cc_power.handle.to_s} = 0
      ENDIF,

      EMS
  ems_program_write_cc_power.setBody(ems_program_write_cc_power_body)

  ems_program_write_cc_power_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
  ems_program_write_cc_power_callingMgr.setName("Write_Real_RTU_CC_Power_to_OtherEquipment_RTU_CallingMgr")
  ems_program_write_cc_power_callingMgr.setCallingPoint("BeginZoneTimestepBeforeInitHeatBalance")
  ems_program_write_cc_power_callingMgr.addProgram(ems_program_write_cc_power)

  #Create Initialization Programs
  ems_program_initialization = OpenStudio::Model::EnergyManagementSystemProgram.new(model)
  ems_program_initialization.setName("Initialization_Program")
  ems_program_initialization_body = <<-EMS

  SET #{ems_GV_fan_power.handle.to_s} = 0
  SET #{ems_GV_fan_power_enable.handle.to_s} = 0
  SET #{ems_GV_cc_power.handle.to_s} = 0
  SET #{ems_GV_cc_power_enable.handle.to_s} = 0

  EMS
  ems_program_initialization.setBody(ems_program_initialization_body)

  ems_program_initialization_callingMgr = OpenStudio::Model::EnergyManagementSystemProgramCallingManager.new(model)
  ems_program_initialization_callingMgr.setName("Initialization_Program_CallingMgr")
  ems_program_initialization_callingMgr.setCallingPoint("BeginNewEnvironment")
  ems_program_initialization_callingMgr.addProgram(ems_program_initialization)


    # report initial condition of model
    runner.registerInitialCondition("The building started with #{model.getSpaces.size} spaces.")


    # report final condition of model
    runner.registerFinalCondition("The building finished with #{model.getSpaces.size} spaces.")

    return true
  end
end

# register the measure to be used by the application
RTUCoordinationJan2020.new.registerWithApplication
