

###### (Automatically generated documentation)

# Create DOE Prototype Building

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Building Type.

**Name:** building_type,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Template.

**Name:** template,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Climate Zone.

**Name:** climate_zone,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Climate File (NECB only)

**Name:** epw_file,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false




